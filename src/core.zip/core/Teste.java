package core;

public class Teste {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 System.out.print("olas");
	}

}
